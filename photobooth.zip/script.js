const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const context = canvas.getContext('2d');
const frame = document.getElementById('frame');

navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
        video.srcObject = stream;
    })
    .catch(error => {
        console.error("Error accessing webcam: ", error);
    });

function capturePhoto() {
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    context.drawImage(frame, 0, 0, canvas.width, canvas.height);
    canvas.style.display = 'block';
    video.style.display = 'none';
}

function downloadPhoto() {
    const link = document.createElement('a');
    link.download = 'photo.png';
    link.href = canvas.toDataURL();
    link.click();
}